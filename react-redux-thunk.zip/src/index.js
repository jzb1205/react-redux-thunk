import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import {Provider} from "react-redux";
import store from './store'
import * as aaa from 'history' 


// import { Router,withRouter } from 'react-router-dom'
import { HashRouter} from 'react-router-dom'
// import history from './view/history';
import { renderRoutes } from 'react-router-config';
import  { routes } from './router' 
import { Layout, Menu } from 'antd';
import {
  MenuUnfoldOutlined,
  MenuFoldOutlined,
  UserOutlined,
  VideoCameraOutlined,
  UploadOutlined,
} from '@ant-design/icons';

const { Header, Sider, Content } = Layout;

class SiderDemo extends React.Component {
  constructor (props) {
    super(props)
    this.state = {
      collapsed: false,
      current:1
    };
  }
  toggle = () => {
    this.setState({
      collapsed: !this.state.collapsed,
    });
  };
  handleClick = e => {
    // this.setState({
    //   current: e.key,
    // });
    // this.props.history.push(e.key);
    console.log('this.props',this.props)
  };
  render() {
    return (
      <Provider store={store}>
        <React.StrictMode>
          {/* <Router store={store}> */}
          <HashRouter store={store}>
            <Layout>
              <Layout className="site-layout">
                <Header className="site-layout-background" style={{ padding: 0 }}>
                  {React.createElement(this.state.collapsed ? MenuUnfoldOutlined : MenuFoldOutlined, {
                    className: 'trigger',
                    onClick: this.toggle,
                  })}
                </Header>
                <Content
                  className="site-layout-background"
                  style={{
                    margin: '24px 16px',
                    padding: 24,
                    minHeight: 280,
                  }}
                >
                  {renderRoutes(routes)}
                </Content>
              </Layout>
            </Layout>
            {/* </Router> */}
          </HashRouter>  
        </React.StrictMode>
      </Provider>
    );
  }
}
ReactDOM.render(<SiderDemo />, document.getElementById('root'));

