import React, { Component } from 'react'
import { Link,withRouter } from 'react-router-dom';
/* 
后台管理的路由页面 
*/

const Admin = ()=>{
    render() {
        let num = this.props.match.params.num
        return (
            <div>
                Admin123 {num}
            </div>
        )
    }
}

class Admin extends Component {
    constructor(props){
        super(props);
        console.log(this.props)
    }
    render() {
        let num = this.props.match.params.num
        return (
            <div>
                Admin123 {num}
            </div>
        )
    }
}
export default withRouter(Admin)